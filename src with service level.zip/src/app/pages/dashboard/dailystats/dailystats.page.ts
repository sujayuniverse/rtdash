import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dailystats',
  templateUrl: './dailystats.page.html',
  styleUrls: ['./dailystats.page.scss'],
})
export class DailystatsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
