import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-charttest',
  templateUrl: './charttest.page.html',
  styleUrls: ['./charttest.page.scss'],
})
export class CharttestPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
